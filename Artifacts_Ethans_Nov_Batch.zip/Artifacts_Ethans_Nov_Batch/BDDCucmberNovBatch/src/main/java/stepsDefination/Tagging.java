package stepsDefination;

import cucumber.api.java.en.Given;

public class Tagging {
	
	@Given("^test one$")
	public void test_one() throws Throwable {
	  System.out.println("test one");
	}

	@Given("^test two$")
	public void test_two() throws Throwable {
		System.out.println("test two");
	}

	@Given("^test three$")
	public void test_three() throws Throwable {
		System.out.println("test three");
	}

}
