package stepsDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login {
	
	WebDriver driver;
	
	@Given("^User launch the flight application$")
	public void user_launch_the_flight_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		 driver = new ChromeDriver();
		driver.get("http://newtours.demoaut.com/");
		
		Thread.sleep(5000);
		
		
	}
	
	@When("^User enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enter_and(String userName, String password) throws Throwable {
		driver.findElement(By.name("userName")).sendKeys(userName);
		driver.findElement(By.name("password")).sendKeys(password);
	}

	/*
	 * @When("^User enter username and password$") public void
	 * user_enter_username_and_password() throws Throwable {
	 * 
	 * }
	 */
	@And("^User click on login button$")
	public void user_click_on_login_button() throws Throwable {
	   driver.findElement(By.name("login")).click();
	}

	@Then("^user navigate to flight home page$")
	public void user_navigate_to_flight_home_page() throws Throwable {
	   
		System.out.println("user is on home page");
	}



}
