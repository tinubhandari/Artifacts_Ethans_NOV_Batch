package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\test\\resources\\taggingNew.feature", glue="stepsDefination",
format= {"html:test-output"} , monochrome = true , tags= {"@regression,@smoke"})
public class Runner {

}
