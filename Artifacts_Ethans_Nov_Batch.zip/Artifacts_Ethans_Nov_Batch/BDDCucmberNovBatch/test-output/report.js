$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/taggingNew.feature");
formatter.feature({
  "line": 1,
  "name": "tagginggNew",
  "description": "",
  "id": "tagginggnew",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Verify testOne",
  "description": "",
  "id": "tagginggnew;verify-testone",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@smoke"
    },
    {
      "line": 3,
      "name": "@regression"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "test one",
  "keyword": "Given "
});
formatter.match({
  "location": "Tagging.test_one()"
});
formatter.result({
  "duration": 164245800,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "Verify testTwo",
  "description": "",
  "id": "tagginggnew;verify-testtwo",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 7,
      "name": "@regression"
    }
  ]
});
formatter.step({
  "line": 9,
  "name": "test two",
  "keyword": "Given "
});
formatter.match({
  "location": "Tagging.test_two()"
});
formatter.result({
  "duration": 63100,
  "status": "passed"
});
});