package APITest;

import java.io.IOException;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class GetRequestTest {

	public static void main(String[] args) throws ClientProtocolException, IOException {

		CloseableHttpClient CloseableHttpClient = HttpClients.createDefault();
		HttpGet get = new HttpGet("https://reqres.in/api/users?page=2");
		CloseableHttpResponse closeableHttpResponse = CloseableHttpClient.execute(get);

		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();

		System.out.println(statusCode);

		// Below code is to read headers

		/*
		 * Header[] headers = closeableHttpResponse.getAllHeaders(); for(int i =0 ;
		 * i<headers.length;i++) { String sHeaderKey = headers[i].getName(); String
		 * sHeaderValue = headers[i].getValue();
		 * 
		 * System.out.println(sHeaderKey + "--> " + sHeaderValue); }
		 */
		// Below code is to read the response body

		String response = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
		// System.out.println(response);

		JSONObject jSONObj = new JSONObject(response);
		Integer sTotal = (Integer) jSONObj.get("total");
		Integer sPage = (Integer) jSONObj.get("page");
		System.out.println(" Total --> " + sTotal + " and page --> " + sPage);

		JSONArray JSON_array = jSONObj.getJSONArray("data");
		JSONObject jSONObJ_dataArray = JSON_array.getJSONObject(0);
		String strEmailId = (String) jSONObJ_dataArray.get("email");
		System.out.println(strEmailId);
	}

}
