package APITest;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class PostApiTest {

	public static void main(String[] args) throws ClientProtocolException, IOException {

		CloseableHttpClient CloseableHttpClient = HttpClients.createDefault();
		HttpPost post = new HttpPost("https://reqres.in/api/users");

		post.addHeader("Content-Type", "application/json");
		//String sToken ="dfgdfshdsfg645754684twer52364568i56ysdvdfjntyyerg" ;
		//post.addHeader("Authorization", "Bearer : "+ sToken);
		//post.addHeader("Authorization", "Basic Auth : "+ "UserName":"password");

		String strRequestPayload = FileUtils
				.readFileToString(new File("D:\\EclipseWorkSpace\\APITestingNovBatch\\JsonPayLoad_Tc01.txt"));

		post.setEntity(new StringEntity(strRequestPayload));

		CloseableHttpResponse closeableHttpResponse = CloseableHttpClient.execute(post);

		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();

		System.out.println(statusCode);

	}

}
