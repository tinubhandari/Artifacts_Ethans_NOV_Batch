package APITest;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class DeleteAPI {

	public static void main(String[] args) throws ClientProtocolException, IOException {

		CloseableHttpClient CloseableHttpClient = HttpClients.createDefault();
		HttpDelete delete = new HttpDelete("https://reqres.in/api/users/2");
		CloseableHttpResponse closeableHttpResponse = 
				CloseableHttpClient.execute(delete);

		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();

		System.out.println(statusCode);

	}

}
