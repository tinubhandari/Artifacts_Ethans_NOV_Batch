package hello;

public class Hello {
	
	public int m1() {
		System.out.println("Hi m1 method");
		return 10;
	
	}

	public static void main(String[] args) {
		System.out.println("hello in main");

	}

}
