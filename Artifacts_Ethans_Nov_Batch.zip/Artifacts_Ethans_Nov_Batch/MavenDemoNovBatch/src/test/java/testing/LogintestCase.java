package testing;

import org.testng.annotations.Test;

public class LogintestCase {
  @Test
  public void verifyLogin() {
	  System.out.println("verify login_updated");
	  
  }
}
