package testing;

import org.testng.annotations.Test;

import hello.Hello;

public class NewTest {
  @Test
  public void testM1() {
	  
	  Hello obj = new Hello();
	   int x= obj.m1();
	   if(x==10) {
		   System.out.println("m1 functionality is passed");
	   }
	   else {
		   throw new NullPointerException();
	   }
	  
	  System.out.println("i am testNG method");
	  //System.out.println(10/0);
	  
	  
  }
}
