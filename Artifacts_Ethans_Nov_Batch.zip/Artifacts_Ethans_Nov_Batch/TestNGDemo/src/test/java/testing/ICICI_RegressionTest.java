package testing;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ICICI_RegressionTest {

	
	/*
	 * @BeforeClass public void beforeclass() { System.out.println(" Before class");
	 * }
	 * 
	 * @AfterClass public void afterclass1() { System.out.println("After class"); }
	 */
	/*
	 * 
	 * 
	 * @BeforeMethod public void SetUpDriver() {
	 * System.out.println(" BeforeMethod Driver launched"); }
	 * 
	 * @AfterMethod public void tearDown() {
	 * System.out.println("After Method Driver closed"); }
	 */

 
 @Parameters({"Env" , "URL"})
 @Test 
  public void VerifyEMail(String environment , String url) {
	 System.out.println("Verify EMail against " +  environment); 
	 System.out.println(url);
	 System.out.println(10/0);
  }
 
 @Test (dependsOnMethods="VerifyEMail",alwaysRun=true)
 public void VerifyAddress() {
	 System.out.println("Verify Address"); 
 }

 
}
