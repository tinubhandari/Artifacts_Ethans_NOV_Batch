package testing;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ICICI_SmokeTest {

	
 @BeforeTest
  public void beforeclass() {
	 System.out.println(" Before test"); 
  }
 
 @AfterTest
 public void afterclass1() {
	 System.out.println("After test"); 
 }
 


 @BeforeMethod
  public void SetUpDriver() {
	 System.out.println(" BeforeMethod Driver launched"); 
  }
 
 @AfterMethod
 public void tearDown() {
	 System.out.println("After Method Driver closed"); 
 }

 
  
 @Test
  public void VerifyLogin() {
	 System.out.println("Verify login"); 
  }
 
 @Test
 public void VerifyOverdraft() {
	 System.out.println("Verify Overdraft"); 
 }

 
}
