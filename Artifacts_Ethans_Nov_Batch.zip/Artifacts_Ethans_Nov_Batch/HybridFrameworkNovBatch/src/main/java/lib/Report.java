package lib;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.codoid.products.exception.FilloException;

public class Report {
	
	/**
	 * @author Ethans
	 * Funnction name :- createHTMLReport
	 * @throws FilloException 
	 */
	public static void createHTMLReport() {
		
		Global.htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")+"\\Reports\\TestResultLogs\\Batch.html");
		Global.report = new ExtentReports();
		Global.report.attachReporter(Global.htmlReporter);	
	}
	
	/**
	 * @author Ethans
	 * Funnction name :- writeHTMLLogs
	 * @throws FilloException 
	 */
	
	
   public static void writeHTMLLogs(String strpassFail , String desc) {
		
	   if(strpassFail.contentEquals("PASS")) {
		   Global.logger.log(Status.PASS, desc);
	   }
	   else if (strpassFail.contentEquals("FAIL")) {
		   Global.logger.log(Status.FAIL, desc);
	   }
	   else {
		   Global.logger.log(Status.INFO, desc);
	   }
		
	}
   
   
   /**
	 * @author dharm
	 * Function Name : takeScreenShot(String strpassFail , String des) 
	 * @throws IOException 
	 */
	public static void takeScreenShot(String strpassFail , String des) throws IOException {
		
		WebDriver driver = Utility.returnDriver();
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		 
		LocalDateTime  localDateTime= LocalDateTime.now();
		String path =  localDateTime.toString().replaceAll(":", "_");
		String strNewPath = Global.gtsrScreenshotPath + "\\" + path + ".png";
		FileHandler.copy(src, new File (strNewPath));
		
		if(strpassFail.contentEquals("PASS")) {
			MediaEntityModelProvider mediaModel = MediaEntityBuilder.createScreenCaptureFromPath(strNewPath).build();
			Global.logger.pass("", mediaModel);
		}
		
		else if (strpassFail.contentEquals("PASS")) {
			MediaEntityModelProvider mediaModel = MediaEntityBuilder.createScreenCaptureFromPath(strNewPath).build();
			Global.logger.fail("", mediaModel);
		}
		
		
	}

	
	
	

}
