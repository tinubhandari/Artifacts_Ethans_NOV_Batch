package seleniumNovTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTableDemo {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.toolsqa.com/automation-practice-table/#");
		
		Thread.sleep(5000);
		
		String Rank = driver.findElement
		(By.xpath("//th[text()='Burj Khalifa']//following-sibling::td[5]")).getText();
		
		System.out.println(Rank);

	}

}
