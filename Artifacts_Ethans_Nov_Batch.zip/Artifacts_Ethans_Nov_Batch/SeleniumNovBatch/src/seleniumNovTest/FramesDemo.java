package seleniumNovTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FramesDemo {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.goibibo.com/");
		
		//Thread.sleep(5000);
		
		driver.findElement(By.linkText("Sign up")).click();
		
		Thread.sleep(5000);
		
		WebElement eleFrame = driver.findElement(By.xpath("//iframe[@id='authiframe']"));
		
		driver.switchTo().frame(eleFrame);
		
		driver.
		findElement
		(By.xpath("//input[@id='authMobile']")).sendKeys("1242345235325");
		
		
		driver.switchTo().defaultContent();
		Thread.sleep(5000);
		
		driver.quit();

	}

}
