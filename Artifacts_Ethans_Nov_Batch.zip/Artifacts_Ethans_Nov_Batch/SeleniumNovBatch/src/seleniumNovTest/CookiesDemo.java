package seleniumNovTest;

import java.util.Set;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CookiesDemo {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		
		driver.get("https://rightstartmath.com/");
		Thread.sleep(5000);
		
		Set <Cookie> allcokkies = driver.manage().getCookies();
		System.out.println("number of cookies :" + allcokkies.size());
		for(Cookie cok :allcokkies ) {
			
			System.out.println(cok.getName() + " and " + cok.getValue());
			
		}
		
		//delete the cookies
		driver.manage().deleteAllCookies();
		
		//How to add the cookies
		Cookie cokkieObj = new Cookie("MyCookie" , "Ethans");
		
		driver.manage().addCookie(cokkieObj);
		
	
		

	}

}
