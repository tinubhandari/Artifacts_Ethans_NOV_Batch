package seleniumNovTest;


import java.util.List;
import java.util.ListIterator;
import java.util.TreeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDemo {

	public static void main(String[] args) throws InterruptedException {
		

		
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		
		Thread.sleep(5000);
		WebElement eleMonth = driver.findElement(By.xpath("//select[@id='month']"));
		
		Select sel = new Select(eleMonth);
		
		
		List <WebElement> allItems= sel.getOptions();
		ListIterator<WebElement> itr= allItems.listIterator();
		TreeSet list_Actual = new TreeSet();
		while(itr.hasNext()) {
			WebElement eleItem = itr.next();
			System.out.println(eleItem.getText());
			if(!eleItem.getText().contentEquals("Month")) {
				list_Actual.add(eleItem.getText().toLowerCase());
			}
			
		}
	Thread.sleep(5000);
		driver.quit();
		

	}

}
