package seleniumNovTest;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButtonDemo {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		
		Thread.sleep(5000);
		
		String sTitle= driver.getTitle();
		
		if(sTitle.contentEquals("Facebook - Log In or Sign Up")) {
			System.out.println("pass");
		}
		else {
			System.out.println("fail to verify title of page");
		}
		
		System.out.println(sTitle);
		
		System.out.println(driver.getCurrentUrl());
		
		String strXpath="Custom";
		
		WebElement ele_Radio = driver.findElement(By.xpath("//label[text()='"+strXpath+"']//parent::span//input"));
		ele_Radio.click();
		
		Thread.sleep(5000);
		
		driver.quit();
		
		ArrayList l = new ArrayList();
		
		String s = new String();
		


		
		

	}

}
