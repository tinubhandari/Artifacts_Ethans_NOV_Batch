package seleniumNovTest;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class CalendarAutomation {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.redbus.in/");
		
		Thread.sleep(9000);
		
		WebElement eleFrom = driver.findElement(By.xpath("//input[@data-message='Please enter a source city']"));
		eleFrom.sendKeys("Pune");
		
		Thread.sleep(5000);
		
		String source = "Swargate, Pune";
		String dest = "Vijay Nagar, Indore";
		
		driver.findElement(By.xpath("//li[text()='"+source+"']")).click();
		
		driver.findElement(By.xpath("//input[@data-message='Please enter a destination city']"))
		.sendKeys("Indore");
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//li[text()='"+dest+"']")).click();
		Thread.sleep(5000);
		
		WebElement ele_MonthNew = driver.findElement(By.id("onward_cal"));
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		js.executeScript("arguments[0]."
				+ "setAttribute('data-caleng','15-Feb-2020')", ele_MonthNew);
		
		js.executeScript("arguments[0].value='15-Feb-2020'", ele_MonthNew);
		Thread.sleep(5000);
		
		
		
		
		while(true) {
			WebElement ele_Month = driver.findElement(
					By.xpath("(//td[@class='monthTitle'])[2]"));
			if(ele_Month.getText().contentEquals("Apr 2020")) {
				
				break;
			}
			else {
				driver.findElement(By.xpath("(//td[@class='next'])[2]")).click();
			}
		}
		
		

		
		
	}

}
