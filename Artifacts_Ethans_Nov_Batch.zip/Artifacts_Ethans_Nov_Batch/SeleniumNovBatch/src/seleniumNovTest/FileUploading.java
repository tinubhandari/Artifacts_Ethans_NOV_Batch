package seleniumNovTest;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FileUploading {

	public static void main(String[] args) throws InterruptedException, AWTException {
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.toolsqa.com/automation-practice-form/");
		
		WebDriverWait wait = new WebDriverWait(driver, 40);
		List <WebElement> eleList = 
				wait.until(ExpectedConditions.numberOfElementsToBe
						(By.xpath("//img[@alt='close-link']"), 1));
		wait.until(ExpectedConditions.elementToBeClickable(eleList.get(0)));
		eleList.get(0).click();
	
		
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("document.querySelector('#photo').click()");
		
		//driver.findElement(By.xpath("//input[@id='photo']"))
		//.sendKeys("D:\\Users\\dsingh\\Desktop\\Selenium_Images\\Map.png");
		
		Thread.sleep(5000);
		
		Robot r = new Robot();
		
		
		StringSelection sel = new StringSelection("D:\\Users\\dsingh\\Desktop\\Selenium_Images\\Map.png");
		
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(sel, sel);
		
		Thread.sleep(9000);
		
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_V);
		r.keyPress(KeyEvent.VK_ENTER);
		
		
		
		r.keyRelease(KeyEvent.VK_CONTROL);
		r.keyRelease(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_ENTER);
		
		
		
		
		

	}

}
