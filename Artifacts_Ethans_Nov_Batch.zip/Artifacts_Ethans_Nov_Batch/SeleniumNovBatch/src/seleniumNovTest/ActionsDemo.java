package seleniumNovTest;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class ActionsDemo {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//WebDriver driver1 = new RemoteWebDriver(new DesiredCapabilities().chrome());
		
		driver.get("https://rightstartmath.com/");
		
		Thread.sleep(5000);
		
		//WebElement ele_Cur = driver.findElement(By.xpath("//a[text()='Curriculum']"));
		//WebElement ele_RightStart = driver.findElement(By.xpath("(//a[text()='The RightStart� Difference'])[1]"));
		//WebElement ele_Home = driver.findElement(By.xpath("(//a[text()='RightStart� for Home School'])[1]"));
		
		Actions act = new Actions(driver);
		//act.moveToElement(ele_Cur).moveToElement(ele_RightStart).
		//moveToElement(ele_Home).click(ele_Home).perform();
		WebElement ele = driver.findElement(By.xpath("//input[@value='Search']"));
		ele.sendKeys("Hello",Keys.TAB);
		

	}

}
