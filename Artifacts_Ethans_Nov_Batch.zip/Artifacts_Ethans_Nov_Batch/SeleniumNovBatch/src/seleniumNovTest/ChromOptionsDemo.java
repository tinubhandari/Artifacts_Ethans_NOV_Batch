package seleniumNovTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ChromOptionsDemo {

	public static void main(String[] args) {
		
		ChromeOptions op = new ChromeOptions();
		//op.setHeadless(true);
		
		//op.addArguments("--headless");
		op.addArguments("start-maximized");
		
		
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(op);
		
	
		
		driver.get("https://rightstartmath.com/");
		
		System.out.println(driver.getTitle());
		

	}

}
