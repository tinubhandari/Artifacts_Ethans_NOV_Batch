package seleniumNovTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetAllLinksName {

	public static void main(String[] args) throws InterruptedException {
		

		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.com");
		
		Thread.sleep(5000);
		
		List<WebElement> eleLinks = driver.findElements(By.tagName("a"));
		
		for(int i=0;i<eleLinks.size();i++) {
			WebElement elelink = eleLinks.get(i);
			String strLinkName= elelink.getText();
			System.out.println(strLinkName);
		}

	}

}
