package seleniumNovTest;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindBrokenLinks {
	
	
	public static int getResponseCode(String strUrl) throws Exception {
        URL url = new URL(strUrl);
		
		HttpURLConnection con = (HttpURLConnection)url.openConnection();
		con.setConnectTimeout(5000);
		con.connect();
		int resCode = con.getResponseCode();
		//System.out.println(resCode); //200 res code
		return resCode;
	}

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		
		Thread.sleep(5000);
		
		List <WebElement>alllinks = driver.findElements(By.tagName("a"));
		
		for(int i =0; i<alllinks.size() ;i++) {
			String strHref_URL= alllinks.get(i).getAttribute("href");
			int statusCode= FindBrokenLinks.getResponseCode(strHref_URL);
			System.out.println("Link name -- > " +alllinks.get(i).getText() +
					" and Status code --> " +statusCode + " and URL -- > "+ strHref_URL );
			
		}
		
		
		
		
	
		

	}

}
