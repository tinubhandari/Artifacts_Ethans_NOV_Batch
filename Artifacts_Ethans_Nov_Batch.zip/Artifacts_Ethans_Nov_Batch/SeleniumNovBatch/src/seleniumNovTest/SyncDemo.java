package seleniumNovTest;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SyncDemo {

	public static void main(String[] args) {
		ChromeOptions op = new ChromeOptions();
		op.addArguments("--disable-notifications");
		
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(op);
		
		driver.get("https://rightstartmath.com/");
		
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		//WebDriverWait code
		WebElement ele = driver.findElement(By.xpath("//input[@value='Search']"));
		
		//WebDriverWait wait = new WebDriverWait(driver,30);
		//ele = wait.until(ExpectedConditions.visibilityOf(ele));
		//ele.sendKeys("Hello");
		
		//++++++++++++++++++++++++++++++++
		//Fluentwait code
		
		FluentWait<WebDriver> fw = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
		
		ele = fw.until(ExpectedConditions.visibilityOf(ele));
		ele.sendKeys("Hello");
		
		
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(30,  TimeUnit.SECONDS);
		
	}

}
