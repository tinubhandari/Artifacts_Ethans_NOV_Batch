package seleniumNovTest;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertDemo {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dsingh\\Downloads\\SeleniumBatch3\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://ksrtc.in/oprs-web/pkg/tours/loadPlaces.do");
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//input[@id='SrvcSelectBtn']")).click();
		
		Thread.sleep(5000);
		
		Alert alert = driver.switchTo().alert();
		
	    String strtText = alert.getText();
	    System.out.println(strtText);
		//alert.accept(); // click on yes , ok
		alert.dismiss(); // click on cancel , no button
		//alert.sendKeys("abc"); // used to enter value on text box
		// which is present on pop-up
		
		
		

	}

}
